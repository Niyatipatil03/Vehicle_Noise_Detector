# src/audacity_labels.py — Parse Audacity label export files

import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import CLASSES, LABEL2ID


def parse_audacity_labels(txt_path: str) -> list:
    if not os.path.exists(txt_path):
        return []
    segments = []
    with open(txt_path, 'r') as f:
        for i, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            parts = line.split('\t')
            if len(parts) < 3:
                print(f"  [WARN] Line {i} bad format: {line}")
                continue
            try:
                start = float(parts[0])
                end   = float(parts[1])
                label = parts[2].strip()
            except ValueError:
                continue
            if label not in LABEL2ID:
                print(f"  [WARN] Unknown label '{label}' — valid: {CLASSES}")
                continue
            if end > start:
                segments.append({
                    'start':     start,
                    'end':       end,
                    'label':     label,
                    'class_idx': LABEL2ID[label],
                })
    return segments


def get_label_file(audio_path: str):
    base = os.path.splitext(audio_path)[0]
    txt  = base + '.txt'
    return txt if os.path.exists(txt) else None
