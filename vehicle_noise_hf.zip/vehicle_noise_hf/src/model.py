# src/model.py — ALM/wav2vec2-base-audioset fine-tuned for vehicle noise
#
# Why this model:
#   - Pretrained on AudioSet (2M clips, 527 classes including engine/rattle/mechanical)
#   - Much closer to vehicle noise than speech-pretrained models
#   - Base size (95MB) — small enough to run on modest hardware
#   - Two-phase training prevents overfitting on small datasets:
#       Phase 1: Freeze backbone → only train classification head
#       Phase 2: Unfreeze last 4 transformer layers → fine-tune together

import torch
import torch.nn as nn
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import NUM_CLASSES, LABEL2ID, ID2LABEL, HF_MODEL_NAME, HF_CACHE_DIR


class VehicleNoiseClassifier(nn.Module):
    """
    wav2vec2-base-audioset backbone + custom classification head.

    Input  : raw waveform tensor (batch, 48000)  — 3s at 16kHz
    Output : class logits (batch, NUM_CLASSES)
    """

    def __init__(self, num_classes=NUM_CLASSES,
                 model_name=HF_MODEL_NAME,
                 cache_dir=HF_CACHE_DIR):
        super().__init__()
        from transformers import Wav2Vec2Model

        print(f"\n  Loading backbone: {model_name}")
        os.makedirs(cache_dir, exist_ok=True)

        # Load only the feature extractor part (no classification head)
        self.wav2vec2 = Wav2Vec2Model.from_pretrained(
            model_name,
            cache_dir=cache_dir,
        )

        hidden_size = self.wav2vec2.config.hidden_size  # 768

        # Custom head for our 7 vehicle noise classes
        self.classifier = nn.Sequential(
            nn.Linear(hidden_size, 512),
            nn.LayerNorm(512),
            nn.GELU(),
            nn.Dropout(0.3),
            nn.Linear(512, 256),
            nn.LayerNorm(256),
            nn.GELU(),
            nn.Dropout(0.2),
            nn.Linear(256, num_classes),
        )

        # Start with backbone frozen
        self.freeze_backbone()
        print(f"  Backbone frozen.")
        print(f"  Trainable params : {self.count_trainable():,}")
        print(f"  Total params     : {self.count_total():,}")

    def freeze_backbone(self):
        """Phase 1: Freeze entire backbone, train head only."""
        for param in self.wav2vec2.parameters():
            param.requires_grad = False
        # Always keep feature extractor frozen (CNN layers)
        for param in self.wav2vec2.feature_extractor.parameters():
            param.requires_grad = False

    def unfreeze_top_layers(self, n_layers: int = 4):
        """
        Phase 2: Unfreeze top N transformer layers for fine-tuning.
        Feature extractor (CNN) stays frozen — only transformer layers unfreeze.
        """
        encoder_layers = self.wav2vec2.encoder.layers
        total          = len(encoder_layers)

        for i, layer in enumerate(encoder_layers):
            if i >= total - n_layers:
                for param in layer.parameters():
                    param.requires_grad = True

        # Also unfreeze layer norm
        for param in self.wav2vec2.encoder.layer_norm.parameters():
            param.requires_grad = True

        print(f"  Unfroze top {n_layers}/{total} transformer layers")
        print(f"  Trainable params : {self.count_trainable():,}")

    def forward(self, input_values: torch.Tensor,
                attention_mask: torch.Tensor = None) -> torch.Tensor:
        """
        Args:
            input_values : (batch, 48000) normalized waveform
            attention_mask: optional (batch, 48000)
        Returns:
            logits: (batch, num_classes)
        """
        outputs = self.wav2vec2(
            input_values,
            attention_mask=attention_mask,
            output_hidden_states=False,
        )
        # Mean pool over time: (batch, time, 768) → (batch, 768)
        hidden = outputs.last_hidden_state.mean(dim=1)
        return self.classifier(hidden)

    def predict_proba(self, input_values: torch.Tensor) -> torch.Tensor:
        self.eval()
        with torch.no_grad():
            return torch.softmax(self.forward(input_values), dim=1)

    def count_trainable(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)

    def count_total(self) -> int:
        return sum(p.numel() for p in self.parameters())
