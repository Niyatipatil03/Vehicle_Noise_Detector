# src/audio_utils.py

import wave
import numpy as np
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import SAMPLE_RATE, SPEECH_THRESHOLD, SPEECH_NOISE_AMP


def load_wav(path: str, target_sr: int = SAMPLE_RATE):
    """Load .wav file, convert to mono float32, resample to target_sr."""
    with wave.open(path, 'rb') as wf:
        sr        = wf.getframerate()
        n_ch      = wf.getnchannels()
        sampwidth = wf.getsampwidth()
        raw       = wf.readframes(wf.getnframes())

    if sampwidth == 1:
        audio = np.frombuffer(raw, dtype=np.uint8).astype(np.float32) / 128.0 - 1.0
    elif sampwidth == 2:
        audio = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    else:
        audio = np.frombuffer(raw, dtype=np.int32).astype(np.float32) / 2147483648.0

    if n_ch == 2:
        audio = audio.reshape(-1, 2).mean(axis=1)

    # Resample if needed
    if sr != target_sr:
        new_len = int(len(audio) * target_sr / sr)
        audio   = np.interp(
            np.linspace(0, len(audio)-1, new_len),
            np.arange(len(audio)), audio
        )
    return audio.astype(np.float32), target_sr


def rms_db(signal: np.ndarray) -> float:
    return float(20 * np.log10(np.sqrt(np.mean(signal**2)) + 1e-9))


def remove_speech(audio: np.ndarray, sr: int) -> tuple[np.ndarray, float]:
    """
    Energy-based VAD — replaces speech frames with low-amp noise.
    Returns (cleaned_audio, speech_percentage).
    """
    frame_ms      = 20
    frame_samples = int(frame_ms * sr / 1000)
    clean         = audio.copy()
    speech, total = 0, 0

    for i in range(0, len(audio) - frame_samples, frame_samples):
        total += 1
        if rms_db(audio[i:i+frame_samples]) > SPEECH_THRESHOLD:
            speech += 1
            clean[i:i+frame_samples] = np.random.normal(
                0, SPEECH_NOISE_AMP, frame_samples).astype(np.float32)

    pct = 100 * speech / max(total, 1)
    return clean, pct


def is_valid_window(audio: np.ndarray,
                    skip_db: float = -15.0,
                    silence_db: float = -50.0) -> bool:
    e = rms_db(audio)
    return silence_db < e < skip_db


def slice_audio(audio, sr, window_sec, hop_sec):
    win = int(window_sec * sr)
    hop = int(hop_sec    * sr)
    return [audio[s:s+win] for s in range(0, len(audio)-win, hop)]


def slice_segment(audio, sr, start_sec, end_sec, window_sec, hop_sec):
    s0  = int(start_sec * sr)
    s1  = min(int(end_sec * sr), len(audio))
    seg = audio[s0:s1]
    win = int(window_sec * sr)
    if len(seg) < win // 2:
        return []
    if len(seg) < win:
        return [seg]
    return slice_audio(seg, sr, window_sec, hop_sec)


def pad_or_crop(audio: np.ndarray, target_len: int) -> np.ndarray:
    """Pad with zeros or crop to exactly target_len samples."""
    if len(audio) >= target_len:
        return audio[:target_len]
    return np.pad(audio, (0, target_len - len(audio)))
