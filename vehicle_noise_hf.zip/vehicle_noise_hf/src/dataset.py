# src/dataset.py — Build HuggingFace compatible dataset from audio files

import os, sys, pickle
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import (
    CLASSES, LABEL2ID, SINGLE_CLASS_DIRS, MIXED_DIR,
    SAMPLE_RATE, WINDOW_SEC, HOP_SEC, MAX_AUDIO_LEN,
    WINDOW_SKIP_DB, SILENCE_THRESHOLD,
    AUGMENT, AUG_MULTIPLIER, OUTPUTS_DIR, RANDOM_SEED
)
from src.audio_utils import (
    load_wav, remove_speech, is_valid_window,
    slice_audio, slice_segment, pad_or_crop
)
from src.audacity_labels import parse_audacity_labels, get_label_file

import torch
from torch.utils.data import Dataset


class VehicleNoiseDataset(Dataset):
    """
    HuggingFace-compatible PyTorch Dataset.
    Returns dict with 'input_values' (raw waveform) and 'labels'.
    wav2vec2 feature extractor normalizes input_values internally.
    """

    def __init__(self, audio_arrays: list, labels: list,
                 feature_extractor=None):
        self.feature_extractor = feature_extractor
        self.labels = labels
        self.audio  = audio_arrays  # list of np.ndarray, each 48000 samples

    def __len__(self):
        return len(self.audio)

    def __getitem__(self, idx):
        audio = self.audio[idx]

        if self.feature_extractor is not None:
            # Let HuggingFace feature extractor normalize + convert
            inputs = self.feature_extractor(
                audio,
                sampling_rate=SAMPLE_RATE,
                return_tensors="pt",
                padding=True,
                max_length=MAX_AUDIO_LEN,
                truncation=True,
            )
            input_values = inputs.input_values.squeeze(0)
        else:
            input_values = torch.FloatTensor(audio)

        return {
            "input_values": input_values,
            "labels":       torch.tensor(self.labels[idx], dtype=torch.long),
        }


def augment_waveform(audio: np.ndarray, sr: int, n: int) -> list:
    """
    Generate n augmented copies of a waveform.
    Simple but effective for small datasets:
      - Gaussian noise
      - Amplitude scaling
      - Time shift
    """
    rng     = np.random.RandomState()
    copies  = [audio]
    for _ in range(n - 1):
        aug = audio.copy()

        # Random amplitude scale
        aug = aug * rng.uniform(0.80, 1.20)

        # Add Gaussian noise
        noise_level = rng.uniform(0.001, 0.008)
        aug = aug + rng.normal(0, noise_level, len(aug)).astype(np.float32)

        # Random time shift (up to 20%)
        shift = int(rng.uniform(-0.2, 0.2) * len(aug))
        aug   = np.roll(aug, shift)

        copies.append(aug.astype(np.float32))
    return copies


def collect_files(directory: str) -> list:
    if not os.path.exists(directory):
        return []
    return [
        os.path.join(directory, f)
        for f in sorted(os.listdir(directory))
        if f.lower().endswith(('.wav', '.mp3', '.m4a'))
    ]


def process_file(audio_path: str, class_idx: int,
                 augment: bool, aug_multiplier: int) -> tuple:
    """Process a single-class audio file → list of (waveform, label)."""
    try:
        audio, sr = load_wav(audio_path, SAMPLE_RATE)
    except Exception as e:
        print(f"  [ERROR] {os.path.basename(audio_path)}: {e}")
        return [], []

    clean, speech_pct = remove_speech(audio, sr)
    windows = slice_audio(clean, sr, WINDOW_SEC, HOP_SEC)
    valid   = [w for w in windows
               if is_valid_window(w, WINDOW_SKIP_DB, SILENCE_THRESHOLD)]

    if not valid:
        print(f"  [WARN] No valid windows: {os.path.basename(audio_path)}")
        return [], []

    all_audio, all_labels = [], []
    for w in valid:
        w_fixed = pad_or_crop(w, MAX_AUDIO_LEN)
        copies  = augment_waveform(w_fixed, sr, aug_multiplier) if augment else [w_fixed]
        all_audio.extend(copies)
        all_labels.extend([class_idx] * len(copies))

    cls  = CLASSES[class_idx]
    aug  = f" → {len(all_audio)} augmented" if augment else ""
    print(f"  [{cls:<16}] {os.path.basename(audio_path):<40} "
          f"| {len(valid)} windows{aug} | speech: {speech_pct:.1f}%")
    return all_audio, all_labels


def process_mixed_file(audio_path: str, txt_path: str,
                       augment: bool, aug_multiplier: int) -> tuple:
    """Process an Audacity-annotated mixed file."""
    try:
        audio, sr = load_wav(audio_path, SAMPLE_RATE)
    except Exception as e:
        print(f"  [ERROR] {os.path.basename(audio_path)}: {e}")
        return [], []

    clean, speech_pct = remove_speech(audio, sr)
    segments          = parse_audacity_labels(txt_path)
    if not segments:
        return [], []

    all_audio, all_labels = [], []
    for seg in segments:
        windows = slice_segment(clean, sr, seg['start'], seg['end'],
                                WINDOW_SEC, HOP_SEC)
        valid   = [w for w in windows
                   if is_valid_window(w, WINDOW_SKIP_DB, SILENCE_THRESHOLD)]
        for w in valid:
            w_fixed = pad_or_crop(w, MAX_AUDIO_LEN)
            copies  = (augment_waveform(w_fixed, sr, aug_multiplier)
                       if augment else [w_fixed])
            all_audio.extend(copies)
            all_labels.extend([seg['class_idx']] * len(copies))

    cls_names = list(set(CLASSES[l] for l in all_labels))
    print(f"  [MIXED] {os.path.basename(audio_path):<40} "
          f"| {len(all_labels)} windows "
          f"| classes: {cls_names} | speech: {speech_pct:.1f}%")
    return all_audio, all_labels


def build_dataset(augment=AUGMENT, aug_multiplier=AUG_MULTIPLIER,
                  cache_path=None) -> tuple:
    """
    Build full dataset from all data folders.
    Returns (audio_arrays, labels) where each audio array is 48000 float32 samples.
    """
    if cache_path and os.path.exists(cache_path):
        print(f"Loading cached dataset from {cache_path}")
        with open(cache_path, 'rb') as f:
            return pickle.load(f)

    np.random.seed(RANDOM_SEED)
    all_audio, all_labels = [], []

    print(f"\n{'='*70}")
    print(" BUILDING DATASET")
    print(f" Model   : ALM/wav2vec2-base-audioset")
    print(f" SR      : {SAMPLE_RATE} Hz  |  Window: {WINDOW_SEC}s")
    print(f"{'='*70}")

    # Single-class folders
    for cls, folder in SINGLE_CLASS_DIRS.items():
        files = collect_files(folder)
        if not files:
            continue
        print(f"\n  --- {cls} ({len(files)} files) ---")
        for path in files:
            a, l = process_file(path, LABEL2ID[cls], augment, aug_multiplier)
            all_audio.extend(a)
            all_labels.extend(l)

    # Mixed / Audacity annotated
    mixed = collect_files(MIXED_DIR)
    if mixed:
        print(f"\n{'='*70}")
        print(" MIXED FILES")
        for path in mixed:
            txt = get_label_file(path)
            if txt is None:
                print(f"  [WARN] No label file for {os.path.basename(path)}")
                continue
            a, l = process_mixed_file(path, txt, augment, aug_multiplier)
            all_audio.extend(a)
            all_labels.extend(l)

    # Summary
    print(f"\n{'='*70}")
    if not all_labels:
        print("  [ERROR] No data found.")
        print("  Add .wav files to data/ folders.")
        return [], []

    from collections import Counter
    counts = Counter(all_labels)
    for i, cls in enumerate(CLASSES):
        n   = counts.get(i, 0)
        bar = '█' * int(20 * n / max(counts.values(), 1))
        print(f"  {cls:<20} {n:>5} samples  {bar}")
    print(f"\n  Total : {len(all_labels)} samples across {len(counts)} classes")

    if cache_path:
        os.makedirs(os.path.dirname(cache_path), exist_ok=True)
        with open(cache_path, 'wb') as f:
            pickle.dump((all_audio, all_labels), f)
        print(f"  Cached → {cache_path}")

    return all_audio, all_labels
