# train.py — Two-phase fine-tuning of wav2vec2-base-audioset
#
# Phase 1 (WARMUP_EPOCHS):   Backbone frozen → only train classifier head
#                             High LR (3e-4), fast convergence
# Phase 2 (FINETUNE_EPOCHS): Unfreeze top 4 transformer layers
#                             Low LR (5e-5), careful fine-tuning
#
# Why two phases?
#   Your dataset is small (40 files → ~600 windows after augmentation).
#   If you unfreeze the backbone immediately, the gradients from your
#   tiny dataset will destroy the rich AudioSet features the model learned.
#   Phase 1 first adapts the head to your classes, THEN Phase 2 gently
#   adjusts the backbone features toward vehicle noise.

import os, sys, json, shutil
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Subset
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (
    classification_report, confusion_matrix, f1_score
)
from transformers import AutoFeatureExtractor
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import (
    CLASSES, NUM_CLASSES, CLASS_COLORS,
    HF_MODEL_NAME, HF_CACHE_DIR,
    MODELS_DIR, OUTPUTS_DIR,
    SAMPLE_RATE, MAX_AUDIO_LEN,
    K_FOLDS, RANDOM_SEED,
    WARMUP_EPOCHS, WARMUP_LR, WARMUP_BATCH,
    FINETUNE_EPOCHS, FINETUNE_LR, FINETUNE_BATCH,
    UNFREEZE_LAYERS, WEIGHT_DECAY, PATIENCE,
    AUGMENT, AUG_MULTIPLIER
)
from src.dataset import build_dataset, VehicleNoiseDataset
from src.model import VehicleNoiseClassifier

os.makedirs(MODELS_DIR,  exist_ok=True)
os.makedirs(OUTPUTS_DIR, exist_ok=True)
torch.manual_seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


# ── Helpers ───────────────────────────────────────────────────────────────────

def compute_class_weights(labels):
    counts  = np.bincount(labels, minlength=NUM_CLASSES).astype(float)
    counts  = np.where(counts == 0, 1.0, counts)
    weights = 1.0 / counts
    weights = weights / weights.sum() * NUM_CLASSES
    return torch.FloatTensor(weights).to(DEVICE)


def collate_fn(batch):
    """Pad waveforms to same length within a batch."""
    input_values = torch.stack([b['input_values'] for b in batch])
    labels       = torch.stack([b['labels']       for b in batch])
    return {'input_values': input_values, 'labels': labels}


def evaluate(model, loader):
    model.eval()
    all_preds, all_labels = [], []
    total_loss = 0.0
    criterion  = nn.CrossEntropyLoss()

    with torch.no_grad():
        for batch in loader:
            xb  = batch['input_values'].to(DEVICE)
            yb  = batch['labels'].to(DEVICE)
            out = model(xb)
            total_loss += criterion(out, yb).item() * len(yb)
            preds = torch.argmax(out, dim=1).cpu().numpy()
            all_preds.extend(preds.tolist())
            all_labels.extend(yb.cpu().numpy().tolist())

    loss     = total_loss / len(loader.dataset)
    acc      = sum(p == l for p,l in zip(all_preds, all_labels)) / len(all_labels)
    f1_macro = f1_score(all_labels, all_preds, average='macro', zero_division=0)
    f1_per   = f1_score(all_labels, all_preds, average=None,
                        labels=list(range(NUM_CLASSES)), zero_division=0)
    return loss, acc, f1_macro, f1_per, all_preds, all_labels


def run_phase(model, tr_dl, vl_dl, epochs, lr, phase_name,
              best_path, class_weights, unfreeze=False, unfreeze_n=4):
    """Run one training phase."""

    if unfreeze:
        model.unfreeze_top_layers(unfreeze_n)

    # Separate LR for backbone vs head
    if unfreeze:
        backbone_params = [p for p in model.wav2vec2.parameters() if p.requires_grad]
        head_params     = list(model.classifier.parameters())
        optimizer = optim.AdamW([
            {'params': backbone_params, 'lr': lr * 0.1},  # lower LR for backbone
            {'params': head_params,     'lr': lr},
        ], weight_decay=WEIGHT_DECAY)
    else:
        optimizer = optim.AdamW(
            filter(lambda p: p.requires_grad, model.parameters()),
            lr=lr, weight_decay=WEIGHT_DECAY
        )

    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    criterion = nn.CrossEntropyLoss(weight=class_weights)

    best_f1       = 0.0
    patience_wait = 0
    history       = []

    print(f"\n  ── {phase_name} ({epochs} epochs, lr={lr}) ──")

    for epoch in range(1, epochs + 1):
        model.train()
        tr_loss = 0.0

        for batch in tr_dl:
            xb  = batch['input_values'].to(DEVICE)
            yb  = batch['labels'].to(DEVICE)
            optimizer.zero_grad()
            out  = model(xb)
            loss = criterion(out, yb)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()
            tr_loss += loss.item() * len(yb)

        scheduler.step()
        tr_loss /= len(tr_dl.dataset)

        vl_loss, vl_acc, vl_f1, vl_f1_per, _, _ = evaluate(model, vl_dl)

        print(f"  Epoch {epoch:3d}/{epochs} | "
              f"tr_loss: {tr_loss:.4f} | "
              f"val_acc: {vl_acc:.3f} | "
              f"val_f1: {vl_f1:.3f}")

        history.append({
            'epoch': epoch, 'tr_loss': tr_loss,
            'vl_loss': vl_loss, 'vl_acc': vl_acc, 'vl_f1': vl_f1
        })

        if vl_f1 > best_f1:
            best_f1       = vl_f1
            patience_wait = 0
            torch.save(model.state_dict(), best_path)
        else:
            patience_wait += 1
            if patience_wait >= PATIENCE:
                print(f"  Early stop at epoch {epoch}")
                break

    return best_f1, history


def plot_confusion_matrix(cm, fold, save_path):
    fig, ax = plt.subplots(figsize=(10, 8), facecolor='#0f0f1a')
    short   = [c.replace('_Noise','').replace('_','\n') for c in CLASSES]
    sns.heatmap(cm, annot=True, fmt='d', ax=ax,
                xticklabels=short, yticklabels=short,
                cmap='Reds', linewidths=0.5,
                annot_kws={'size': 11, 'weight': 'bold'})
    ax.set_title(f'Confusion Matrix — Fold {fold}  (wav2vec2-audioset)',
                 color='white', fontsize=12, fontweight='bold')
    ax.set_xlabel('Predicted', color='#aaa')
    ax.set_ylabel('Actual',    color='#aaa')
    ax.tick_params(colors='#aaa', labelsize=9)
    fig.patch.set_facecolor('#0f0f1a')
    plt.tight_layout()
    plt.savefig(save_path, dpi=130, bbox_inches='tight', facecolor='#0f0f1a')
    plt.close()


def plot_per_class_f1(all_f1, save_path):
    mean_f1 = np.mean(all_f1, axis=0)
    std_f1  = np.std(all_f1,  axis=0)
    colors  = [CLASS_COLORS[c] for c in CLASSES]

    fig, ax = plt.subplots(figsize=(12, 5), facecolor='#0f0f1a')
    bars = ax.bar(range(NUM_CLASSES), mean_f1, yerr=std_f1,
                  color=colors, alpha=0.85, capsize=5, width=0.6,
                  error_kw={'color': 'white', 'linewidth': 1.5})
    ax.set_facecolor('#0d0d1a')
    ax.set_xticks(range(NUM_CLASSES))
    ax.set_xticklabels(
        [c.replace('_Noise','\nNoise').replace('_','\n') for c in CLASSES],
        color='#aaa', fontsize=9
    )
    ax.set_ylabel('F1 Score', color='#aaa')
    ax.set_ylim(0, 1.1)
    ax.set_title('Per-Class F1 — wav2vec2-base-audioset (mean ± std)',
                 color='white', fontsize=12, fontweight='bold')
    ax.tick_params(colors='#666')
    for sp in ax.spines.values(): sp.set_color('#333')
    fig.patch.set_facecolor('#0f0f1a')
    for bar, v in zip(bars, mean_f1):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.03,
                f'{v:.2f}', ha='center', va='bottom', color='white', fontsize=9)
    plt.tight_layout()
    plt.savefig(save_path, dpi=130, bbox_inches='tight', facecolor='#0f0f1a')
    plt.close()


# ── Main ──────────────────────────────────────────────────────────────────────

def train():
    print(f"\n{'='*70}")
    print("  VEHICLE NOISE DETECTOR — wav2vec2-base-audioset Fine-Tuning")
    print(f"{'='*70}")
    print(f"  Backbone : {HF_MODEL_NAME}")
    print(f"  Classes  : {CLASSES}")
    print(f"  Device   : {DEVICE}")
    print(f"  Strategy : Phase1 (head only) → Phase2 (top {UNFREEZE_LAYERS} layers)")

    # Load feature extractor
    print(f"\n  Loading feature extractor...")
    feature_extractor = AutoFeatureExtractor.from_pretrained(
        HF_MODEL_NAME, cache_dir=HF_CACHE_DIR
    )

    # Build dataset
    cache = os.path.join(OUTPUTS_DIR, 'dataset_cache.pkl')
    audio_arrays, labels = build_dataset(
        augment=AUGMENT, aug_multiplier=AUG_MULTIPLIER, cache_path=cache
    )

    if not audio_arrays:
        return

    X   = np.array(labels)
    skf = StratifiedKFold(n_splits=K_FOLDS, shuffle=True,
                           random_state=RANDOM_SEED)
    fold_results  = []
    all_f1_per    = []

    for fold, (tr_idx, vl_idx) in enumerate(skf.split(X, X)):
        fold_num = fold + 1
        print(f"\n{'─'*70}")
        print(f"  FOLD {fold_num}/{K_FOLDS} | "
              f"train: {len(tr_idx)} | val: {len(vl_idx)}")
        print(f"{'─'*70}")

        tr_audio  = [audio_arrays[i] for i in tr_idx]
        tr_labels = [labels[i]       for i in tr_idx]
        vl_audio  = [audio_arrays[i] for i in vl_idx]
        vl_labels = [labels[i]       for i in vl_idx]

        tr_ds = VehicleNoiseDataset(tr_audio, tr_labels, feature_extractor)
        vl_ds = VehicleNoiseDataset(vl_audio, vl_labels, feature_extractor)
        tr_dl = DataLoader(tr_ds, batch_size=WARMUP_BATCH,
                           shuffle=True,  collate_fn=collate_fn, num_workers=0)
        vl_dl = DataLoader(vl_ds, batch_size=WARMUP_BATCH,
                           shuffle=False, collate_fn=collate_fn, num_workers=0)

        model        = VehicleNoiseClassifier().to(DEVICE)
        class_wts    = compute_class_weights(np.array(tr_labels))
        best_path    = os.path.join(MODELS_DIR, f'best_fold{fold_num}.pt')

        # ── Phase 1: Train head only ─────────────────────────────────────────
        best_f1_p1, _ = run_phase(
            model, tr_dl, vl_dl,
            epochs=WARMUP_EPOCHS,
            lr=WARMUP_LR,
            phase_name=f"Phase 1 — head only",
            best_path=best_path,
            class_weights=class_wts,
            unfreeze=False,
        )

        # Load best phase 1 weights before phase 2
        model.load_state_dict(torch.load(best_path, map_location=DEVICE))

        # ── Phase 2: Fine-tune top layers ────────────────────────────────────
        # Smaller batch for gradient stability with backbone unfrozen
        tr_dl2 = DataLoader(tr_ds, batch_size=FINETUNE_BATCH,
                            shuffle=True, collate_fn=collate_fn, num_workers=0)
        vl_dl2 = DataLoader(vl_ds, batch_size=FINETUNE_BATCH,
                            shuffle=False, collate_fn=collate_fn, num_workers=0)

        best_f1_p2, _ = run_phase(
            model, tr_dl2, vl_dl2,
            epochs=FINETUNE_EPOCHS,
            lr=FINETUNE_LR,
            phase_name=f"Phase 2 — fine-tune top {UNFREEZE_LAYERS} layers",
            best_path=best_path,
            class_weights=class_wts,
            unfreeze=True,
            unfreeze_n=UNFREEZE_LAYERS,
        )

        best_f1 = max(best_f1_p1, best_f1_p2)

        # Final evaluation
        model.load_state_dict(torch.load(best_path, map_location=DEVICE))
        _, _, final_f1, final_f1_per, preds, true = evaluate(model, vl_dl2)

        cm     = confusion_matrix(true, preds, labels=list(range(NUM_CLASSES)))
        report = classification_report(true, preds, target_names=CLASSES,
                                       zero_division=0)
        print(f"\n{report}")

        plot_confusion_matrix(
            cm, fold_num,
            os.path.join(OUTPUTS_DIR, f'confusion_fold{fold_num}.png')
        )
        all_f1_per.append(final_f1_per)
        fold_results.append({'fold': fold_num, 'val_f1': best_f1})

    # ── Summary ───────────────────────────────────────────────────────────────
    f1s = [r['val_f1'] for r in fold_results]
    print(f"\n{'='*70}")
    print("  FINAL RESULTS")
    print(f"{'='*70}")
    for r in fold_results:
        print(f"  Fold {r['fold']} — macro F1: {r['val_f1']:.4f}")
    print(f"\n  Mean F1 : {np.mean(f1s):.4f} ± {np.std(f1s):.4f}")

    plot_per_class_f1(all_f1_per,
                      os.path.join(OUTPUTS_DIR, 'per_class_f1.png'))

    best_fold = fold_results[np.argmax(f1s)]['fold']
    shutil.copy(
        os.path.join(MODELS_DIR, f'best_fold{best_fold}.pt'),
        os.path.join(MODELS_DIR, 'best_model.pt')
    )
    print(f"\n  Best model (Fold {best_fold}) → models/best_model.pt")

    summary = {
        'backbone':      HF_MODEL_NAME,
        'classes':       CLASSES,
        'num_classes':   NUM_CLASSES,
        'mean_f1':       float(np.mean(f1s)),
        'std_f1':        float(np.std(f1s)),
        'per_class_f1':  {
            CLASSES[i]: float(np.mean([f[i] for f in all_f1_per]))
            for i in range(NUM_CLASSES)
        },
        'best_fold': best_fold,
    }
    with open(os.path.join(OUTPUTS_DIR, 'training_summary.json'), 'w') as f:
        json.dump(summary, f, indent=2)

    print(f"\n  All outputs saved to outputs/")
    print("  Training complete!\n")


if __name__ == "__main__":
    train()
