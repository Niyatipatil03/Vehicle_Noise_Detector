# config.py

import os

BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
DATA_DIR    = os.path.join(BASE_DIR, "data")
MODELS_DIR  = os.path.join(BASE_DIR, "models")
OUTPUTS_DIR = os.path.join(BASE_DIR, "outputs")

# ── Noise Classes ─────────────────────────────────────────────────────────────
CLASSES = [
    "OK",
    "IP_Noise",
    "Steering_Noise",
    "Sunroof_Noise",
    "Door_Noise",
    "Seat_Noise",
    "Seat_Belt_Noise",
]

NUM_CLASSES  = len(CLASSES)
LABEL2ID     = {c: i for i, c in enumerate(CLASSES)}
ID2LABEL     = {i: c for i, c in enumerate(CLASSES)}

CLASS_DISPLAY = {
    "OK":             "Vehicle OK",
    "IP_Noise":       "IP Panel Noise",
    "Steering_Noise": "Steering Noise",
    "Sunroof_Noise":  "Sunroof Noise",
    "Door_Noise":     "Door Noise",
    "Seat_Noise":     "Seat Noise",
    "Seat_Belt_Noise":"Seat Belt Noise",
}

CLASS_COLORS = {
    "OK":             "#00C853",
    "IP_Noise":       "#FF6D00",
    "Steering_Noise": "#2979FF",
    "Sunroof_Noise":  "#AA00FF",
    "Door_Noise":     "#FFD600",
    "Seat_Noise":     "#00BCD4",
    "Seat_Belt_Noise":"#F50057",
}

# Data folders
SINGLE_CLASS_DIRS = {cls: os.path.join(DATA_DIR, cls) for cls in CLASSES}
MIXED_DIR         = os.path.join(DATA_DIR, "mixed")

# ── HuggingFace Model ─────────────────────────────────────────────────────────
HF_MODEL_NAME   = "ALM/wav2vec2-base-audioset"
HF_CACHE_DIR    = os.path.join(MODELS_DIR, "hf_cache")

# ── Audio ─────────────────────────────────────────────────────────────────────
SAMPLE_RATE     = 16000    # wav2vec2 expects 16kHz
WINDOW_SEC      = 3.0      # each training window = 3 seconds
HOP_SEC         = 1.0      # hop between windows
MAX_AUDIO_LEN   = int(WINDOW_SEC * SAMPLE_RATE)  # 48000 samples

# Speech removal
SPEECH_THRESHOLD   = -20.0
SILENCE_THRESHOLD  = -50.0
WINDOW_SKIP_DB     = -15.0
SPEECH_NOISE_AMP   = 0.002

# ── Training ──────────────────────────────────────────────────────────────────
# Phase 1 — freeze backbone, train head only
WARMUP_EPOCHS       = 8
WARMUP_LR           = 3e-4
WARMUP_BATCH        = 16

# Phase 2 — unfreeze last N layers + head
FINETUNE_EPOCHS     = 20
FINETUNE_LR         = 5e-5
FINETUNE_BATCH      = 8
UNFREEZE_LAYERS     = 4

WEIGHT_DECAY        = 1e-3
PATIENCE            = 8
K_FOLDS             = 5
RANDOM_SEED         = 42

# ── Augmentation ──────────────────────────────────────────────────────────────
AUGMENT         = True
AUG_MULTIPLIER  = 15   # each window → 15 augmented copies

# ── Inference ─────────────────────────────────────────────────────────────────
CONFIDENCE_THRESHOLD = 0.40
VOTE_THRESHOLD       = 0.30
