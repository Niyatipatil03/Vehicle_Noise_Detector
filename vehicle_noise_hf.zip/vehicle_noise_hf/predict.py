# predict.py — Inference using fine-tuned wav2vec2-base-audioset

import os, sys, argparse
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from transformers import AutoFeatureExtractor

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import (
    CLASSES, ID2LABEL, CLASS_DISPLAY, CLASS_COLORS,
    HF_MODEL_NAME, HF_CACHE_DIR, MODELS_DIR, OUTPUTS_DIR,
    SAMPLE_RATE, WINDOW_SEC, HOP_SEC, MAX_AUDIO_LEN,
    CONFIDENCE_THRESHOLD, VOTE_THRESHOLD, WINDOW_SKIP_DB, SILENCE_THRESHOLD
)
from src.audio_utils import (
    load_wav, remove_speech, is_valid_window,
    slice_audio, pad_or_crop
)
from src.model import VehicleNoiseClassifier

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
os.makedirs(OUTPUTS_DIR, exist_ok=True)


def load_model(path=None):
    path = path or os.path.join(MODELS_DIR, 'best_model.pt')
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"No model at {path}. Run train.py first."
        )
    model = VehicleNoiseClassifier().to(DEVICE)
    model.load_state_dict(torch.load(path, map_location=DEVICE))
    model.eval()
    print(f"  Model loaded from {path}")
    return model


def predict_file(path, model, feature_extractor, save_plot=True):
    """Run full inference on a single audio file."""
    print(f"\n  Analyzing: {os.path.basename(path)}")
    print(f"  {'─'*48}")

    # Load + clean
    audio, sr  = load_wav(path, SAMPLE_RATE)
    clean, pct = remove_speech(audio, sr)
    print(f"  Duration        : {len(audio)/sr:.1f}s")
    print(f"  Speech removed  : {pct:.1f}%")

    # Slice
    windows = slice_audio(clean, sr, WINDOW_SEC, HOP_SEC)
    valid   = [w for w in windows
               if is_valid_window(w, WINDOW_SKIP_DB, SILENCE_THRESHOLD)]
    print(f"  Valid windows   : {len(valid)} / {len(windows)}")

    if not valid:
        print("  No valid windows found.")
        return None

    # Run model on each window
    all_probs = []
    with torch.no_grad():
        for w in valid:
            w_fixed = pad_or_crop(w, MAX_AUDIO_LEN)
            inputs  = feature_extractor(
                w_fixed, sampling_rate=SAMPLE_RATE,
                return_tensors="pt",
                padding=True, max_length=MAX_AUDIO_LEN, truncation=True
            )
            xb    = inputs.input_values.to(DEVICE)
            probs = torch.softmax(model(xb), dim=1).cpu().numpy()[0]
            all_probs.append(probs)

    all_probs  = np.array(all_probs)          # (n_windows, 7)
    mean_probs = all_probs.mean(axis=0)       # (7,)

    predicted_idx   = int(np.argmax(mean_probs))
    predicted_class = ID2LABEL[predicted_idx]
    confidence      = float(mean_probs[predicted_idx])

    if confidence < CONFIDENCE_THRESHOLD:
        predicted_class = "UNCERTAIN"

    # Print result
    print(f"\n  ┌────────────────────────────────────────┐")
    print(f"  │  RESULT  : {CLASS_DISPLAY.get(predicted_class, predicted_class):<29}│")
    print(f"  │  Confidence : {confidence:.1%:<28}│")
    print(f"  └────────────────────────────────────────┘")

    print(f"\n  Per-class probabilities:")
    for i, cls in enumerate(CLASSES):
        bar  = '█' * int(20 * mean_probs[i])
        flag = ' ◄' if i == predicted_idx else ''
        print(f"    {cls:<20} {mean_probs[i]:.3f}  {bar}{flag}")

    if save_plot:
        _save_prediction_plot(path, audio, sr, all_probs,
                              mean_probs, predicted_class, confidence)

    return {
        'file':            os.path.basename(path),
        'predicted_class': predicted_class,
        'display_name':    CLASS_DISPLAY.get(predicted_class, predicted_class),
        'confidence':      confidence,
        'mean_probs':      mean_probs.tolist(),
        'speech_pct':      pct,
        'n_windows':       len(valid),
    }


def _save_prediction_plot(path, audio, sr, all_probs, mean_probs,
                           predicted_class, confidence):
    fname = os.path.splitext(os.path.basename(path))[0]
    out   = os.path.join(OUTPUTS_DIR, f'prediction_{fname}.png')
    color = CLASS_COLORS.get(predicted_class, '#888888')
    BG    = '#0d0d1a'

    fig, axes = plt.subplots(1, 3, figsize=(18, 5), facecolor='#0f0f1a')

    # Waveform
    ax = axes[0]
    t  = np.linspace(0, len(audio)/sr, len(audio))
    ax.plot(t[::200], audio[::200], color='#00a8ff', linewidth=0.4, alpha=0.7)
    ax.set_facecolor(BG)
    ax.set_title('Waveform', color='white', fontsize=10)
    ax.set_xlabel('Time (s)', color='#aaa', fontsize=9)
    ax.tick_params(colors='#666')
    for sp in ax.spines.values(): sp.set_color('#333')

    # Class probability bars
    ax = axes[1]
    colors = [CLASS_COLORS[c] for c in CLASSES]
    bars   = ax.barh(CLASSES, mean_probs, color=colors, alpha=0.85)
    ax.set_facecolor(BG)
    ax.set_title('Class Probabilities', color='white', fontsize=10)
    ax.set_xlim(0, 1)
    ax.axvline(CONFIDENCE_THRESHOLD, color='white',
               linewidth=1, linestyle='--', alpha=0.4, label='Threshold')
    ax.tick_params(colors='#888')
    for sp in ax.spines.values(): sp.set_color('#333')
    for bar, p in zip(bars, mean_probs):
        ax.text(min(p + 0.02, 0.92), bar.get_y() + bar.get_height()/2,
                f'{p:.2f}', va='center', color='white', fontsize=9)

    # Per-window heatmap
    ax = axes[2]
    im = ax.imshow(
        all_probs.T, aspect='auto', origin='lower',
        extent=[0, len(all_probs), -0.5, len(CLASSES)-0.5],
        cmap='hot', vmin=0, vmax=1
    )
    ax.set_yticks(range(len(CLASSES)))
    ax.set_yticklabels(CLASSES, fontsize=8)
    ax.set_facecolor(BG)
    ax.set_title('Per-Window Probabilities', color='white', fontsize=10)
    ax.set_xlabel('Window index', color='#aaa', fontsize=9)
    ax.tick_params(colors='#888')
    for sp in ax.spines.values(): sp.set_color('#333')
    plt.colorbar(im, ax=ax)

    fig.suptitle(
        f"{os.path.basename(path)}  →  "
        f"{CLASS_DISPLAY.get(predicted_class, predicted_class)}  "
        f"({confidence:.1%} confidence)",
        color=color, fontsize=13, fontweight='bold'
    )
    plt.tight_layout()
    plt.savefig(out, dpi=130, bbox_inches='tight', facecolor='#0f0f1a')
    plt.close()
    print(f"\n  Plot saved → {out}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Predict vehicle noise type using fine-tuned wav2vec2"
    )
    parser.add_argument("files", nargs="+", help=".wav files to analyze")
    parser.add_argument("--model", default=None, help="Model checkpoint path")
    args = parser.parse_args()

    print(f"\n  Loading feature extractor: {HF_MODEL_NAME}")
    feature_extractor = AutoFeatureExtractor.from_pretrained(
        HF_MODEL_NAME, cache_dir=HF_CACHE_DIR
    )
    model = load_model(args.model)

    for f in args.files:
        if os.path.exists(f):
            predict_file(f, model, feature_extractor)
        else:
            print(f"  File not found: {f}")
