# validate_labels.py — Check all Audacity label files before training

import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import CLASSES, MIXED_DIR, SINGLE_CLASS_DIRS
from src.audio_utils import load_wav
from src.audacity_labels import parse_audacity_labels, get_label_file
from src.dataset import collect_files


def main():
    print("=" * 60)
    print(" LABEL VALIDATION")
    print("=" * 60)

    issues = 0

    print("\n--- Single-class folders ---")
    for cls, folder in SINGLE_CLASS_DIRS.items():
        files = collect_files(folder)
        status = f"{len(files)} files" if files else "EMPTY"
        print(f"  [{cls:<20}] {status}")
        if not files:
            issues += 1

    print("\n--- Mixed / Audacity annotated ---")
    mixed = collect_files(MIXED_DIR)
    if not mixed:
        print("  No mixed files (this is fine if all files are in class folders)")
    else:
        for audio_path in mixed:
            txt = get_label_file(audio_path)
            if txt is None:
                print(f"  [MISSING] {os.path.basename(audio_path)}")
                print(f"    Expected: {os.path.splitext(audio_path)[0]}.txt")
                issues += 1
                continue

            audio, sr = load_wav(audio_path)
            duration  = len(audio) / sr
            segments  = parse_audacity_labels(txt)

            print(f"\n  {os.path.basename(audio_path)} ({duration:.1f}s)")
            if not segments:
                print(f"    [ERROR] No valid segments found")
                issues += 1
            else:
                for seg in segments:
                    print(f"    {seg['start']:6.1f}s → {seg['end']:6.1f}s  "
                          f"[{seg['label']}]")

    print(f"\n{'='*60}")
    if issues == 0:
        print("  All OK — ready to train!")
        print("  Run: python train.py")
    else:
        print(f"  {issues} issue(s) found — fix before training")
    print("=" * 60)


if __name__ == "__main__":
    main()
