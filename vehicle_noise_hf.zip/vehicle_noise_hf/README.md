# Vehicle Noise Detector — wav2vec2-base-audioset

Fine-tuned HuggingFace model for vehicle noise classification.
Backbone: `ALM/wav2vec2-base-audioset` — pretrained on 2M AudioSet clips.

## Why this model?
- AudioSet contains engine sounds, rattles, mechanical noise — close to vehicle noise
- Transfer learning works well even with small datasets (40 files)
- Two-phase training prevents overfitting

## Setup

```cmd
python -m venv myenv
myenv\Scripts\activate

pip install numpy scikit-learn matplotlib soundfile seaborn tqdm pandas
pip install torch torchaudio --index-url https://download.pytorch.org/whl/cpu
pip install transformers accelerate datasets
```

## Data folders

```
data/
├── OK/              ← OK vehicle .wav files
├── IP_Noise/        ← IP panel noise .wav files
├── Steering_Noise/  ← Steering noise .wav files
├── Sunroof_Noise/   ← Sunroof noise .wav files
├── Door_Noise/      ← Door noise .wav files
├── Seat_Noise/      ← Seat noise .wav files
├── Seat_Belt_Noise/ ← Seat belt noise .wav files
└── mixed/           ← Files with multiple noise types
    ├── file.wav     ← audio
    └── file.txt     ← Audacity label file (same base name)
```

## Run

```cmd
# Validate labels first
python validate_labels.py

# Train (downloads wav2vec2 model ~95MB on first run)
python train.py

# Predict
python predict.py data\OK\your_file.wav
```

## Training strategy

```
Phase 1 (8 epochs):   Backbone FROZEN → only train 7-class head
                       LR = 3e-4, Batch = 16
                       Fast convergence, no overfitting risk

Phase 2 (20 epochs):  Unfreeze top 4 transformer layers
                       LR = 5e-5 (backbone), 5e-4 (head)
                       Batch = 8 (smaller for stability)
                       Gradually adapts AudioSet features to vehicle noise
```

## Adding a new noise class

1. Add class name to `CLASSES` in `config.py`
2. Create `data/NewClass/` folder and add `.wav` files
3. Delete `outputs/dataset_cache.pkl`
4. Run `python train.py`
