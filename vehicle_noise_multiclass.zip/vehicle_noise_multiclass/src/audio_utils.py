# src/audio_utils.py — Audio loading, resampling, speech removal

import wave
import numpy as np
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import SAMPLE_RATE, SPEECH_ENERGY_THRESHOLD, SPEECH_REPLACEMENT_AMP


def load_wav(path: str, target_sr: int = SAMPLE_RATE):
    with wave.open(path, 'rb') as wf:
        sr        = wf.getframerate()
        n_ch      = wf.getnchannels()
        sampwidth = wf.getsampwidth()
        raw       = wf.readframes(wf.getnframes())

    if sampwidth == 1:
        audio = np.frombuffer(raw, dtype=np.uint8).astype(np.float32) / 128.0 - 1.0
    elif sampwidth == 2:
        audio = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    else:
        audio = np.frombuffer(raw, dtype=np.int32).astype(np.float32) / 2147483648.0

    if n_ch == 2:
        audio = audio.reshape(-1, 2).mean(axis=1)

    if sr != target_sr:
        new_len = int(len(audio) * target_sr / sr)
        audio = np.interp(
            np.linspace(0, len(audio) - 1, new_len),
            np.arange(len(audio)), audio
        )

    return audio.astype(np.float32), target_sr


def rms_db(signal: np.ndarray) -> float:
    return float(20 * np.log10(np.sqrt(np.mean(signal ** 2)) + 1e-9))


def remove_speech_energy_vad(audio, sr, frame_ms=20.0):
    frame_samples = int(frame_ms * sr / 1000)
    clean = audio.copy()
    speech_frames = 0
    total_frames  = 0
    for i in range(0, len(audio) - frame_samples, frame_samples):
        frame = audio[i:i + frame_samples]
        total_frames += 1
        if rms_db(frame) > SPEECH_ENERGY_THRESHOLD:
            speech_frames += 1
            clean[i:i + frame_samples] = np.random.normal(
                0, SPEECH_REPLACEMENT_AMP, frame_samples
            ).astype(np.float32)
    speech_pct = 100 * speech_frames / max(total_frames, 1)
    return clean, speech_pct


def is_valid_window(audio, skip_threshold=-15.0, silence_threshold=-50.0):
    e = rms_db(audio)
    return silence_threshold < e < skip_threshold


def slice_audio(audio, sr, window_sec, hop_sec):
    win = int(window_sec * sr)
    hop = int(hop_sec * sr)
    return [audio[s:s + win] for s in range(0, len(audio) - win, hop)]


def slice_audio_segment(audio, sr, start_sec, end_sec, window_sec, hop_sec):
    """Slice only a specific time segment of audio (used for Audacity annotations)."""
    start_sample = int(start_sec * sr)
    end_sample   = min(int(end_sec * sr), len(audio))
    segment      = audio[start_sample:end_sample]
    if len(segment) < int(window_sec * sr):
        return [segment] if len(segment) > int(window_sec * sr * 0.5) else []
    return slice_audio(segment, sr, window_sec, hop_sec)
