# src/audacity_labels.py
# Reads Audacity label export files (.txt) and returns time-stamped segments.
#
# Audacity export format (File → Export → Export Labels):
#   start_time\tend_time\tlabel
#   0.000000\t1.523400\tOK
#   1.523400\t2.980000\tIP_Noise
#   3.100000\t4.200000\tSteering_Noise
#
# Usage:
#   labels = parse_audacity_labels("audio_file.txt")
#   # returns: [{'start': 0.0, 'end': 1.52, 'label': 'OK'}, ...]

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import CLASSES, CLASS_TO_IDX


def parse_audacity_labels(txt_path: str) -> list[dict]:
    """
    Parse an Audacity label file and return a list of labelled segments.
    Skips any labels not in the CLASSES list (e.g. typos or speech markers).

    Returns list of dicts: [{'start': float, 'end': float, 'label': str, 'class_idx': int}]
    """
    if not os.path.exists(txt_path):
        return []

    segments = []
    with open(txt_path, 'r') as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            parts = line.split('\t')
            if len(parts) < 3:
                print(f"  [WARN] Line {line_num} in {os.path.basename(txt_path)} "
                      f"has wrong format, skipping: {line}")
                continue

            try:
                start = float(parts[0])
                end   = float(parts[1])
                label = parts[2].strip()
            except ValueError:
                print(f"  [WARN] Could not parse line {line_num}: {line}")
                continue

            if label not in CLASS_TO_IDX:
                print(f"  [WARN] Unknown label '{label}' on line {line_num} — "
                      f"valid labels: {CLASSES}")
                continue

            if end <= start:
                print(f"  [WARN] Invalid segment (end <= start) on line {line_num}")
                continue

            segments.append({
                'start':     start,
                'end':       end,
                'label':     label,
                'class_idx': CLASS_TO_IDX[label],
                'duration':  end - start,
            })

    return segments


def get_label_file(audio_path: str) -> str | None:
    """
    Given an audio file path, return the matching Audacity label file path.
    Looks for a .txt file with the same base name in the same directory.

    Example:
        audio_path = "data/mixed/vehicle_001.wav"
        returns    = "data/mixed/vehicle_001.txt"  (if it exists)
        returns    = None (if no label file found)
    """
    base   = os.path.splitext(audio_path)[0]
    txt    = base + '.txt'
    return txt if os.path.exists(txt) else None


def validate_label_file(txt_path: str, audio_duration_sec: float) -> bool:
    """
    Check that a label file is valid:
    - Has at least one segment
    - All segments are within audio duration
    - Labels are all valid class names
    """
    segments = parse_audacity_labels(txt_path)
    if not segments:
        print(f"  [ERROR] No valid segments in {os.path.basename(txt_path)}")
        return False

    issues = 0
    for seg in segments:
        if seg['end'] > audio_duration_sec + 0.5:  # 0.5s tolerance
            print(f"  [WARN] Segment [{seg['start']:.1f}-{seg['end']:.1f}] "
                  f"exceeds audio duration {audio_duration_sec:.1f}s")
            issues += 1

    if issues == 0:
        print(f"  [OK] {os.path.basename(txt_path)}: "
              f"{len(segments)} segments, "
              f"classes: {list(set(s['label'] for s in segments))}")
    return True
