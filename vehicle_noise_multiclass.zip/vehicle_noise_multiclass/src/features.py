# src/features.py — Mel spectrogram feature extraction

import numpy as np
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import SAMPLE_RATE, N_FFT, HOP_LENGTH, N_MELS, F_MIN, F_MAX, TARGET_FRAMES, TIME_MASK_RATIO, FREQ_MASK_RATIO


def build_mel_filterbank(sr, n_fft, n_mels, fmin, fmax):
    mel_min = 2595 * np.log10(1 + fmin / 700)
    mel_max = 2595 * np.log10(1 + fmax / 700)
    mels    = np.linspace(mel_min, mel_max, n_mels + 2)
    hz      = 700 * (10 ** (mels / 2595) - 1)
    bins    = np.floor((n_fft + 1) * hz / sr).astype(int)
    bins    = np.clip(bins, 0, n_fft // 2)
    fb      = np.zeros((n_mels, n_fft // 2 + 1), dtype=np.float32)
    for m in range(1, n_mels + 1):
        lo, mid, hi = bins[m-1], bins[m], bins[m+1]
        for k in range(lo, mid):
            fb[m-1, k] = (k - lo) / (mid - lo + 1e-8)
        for k in range(mid, hi):
            fb[m-1, k] = (hi - k) / (hi - mid + 1e-8)
    return fb


_FB = build_mel_filterbank(SAMPLE_RATE, N_FFT, N_MELS, F_MIN, F_MAX)


def audio_to_melspec(audio, sr=SAMPLE_RATE, normalize=True):
    audio   = np.pad(audio, N_FFT // 2)
    hann    = np.hanning(N_FFT)
    frames  = np.array([
        audio[i:i + N_FFT] * hann
        for i in range(0, len(audio) - N_FFT, HOP_LENGTH)
    ], dtype=np.float32)
    power   = np.abs(np.fft.rfft(frames, n=N_FFT)) ** 2
    mel     = np.dot(power, _FB.T).T               # (n_mels, time)
    mel_db  = 10 * np.log10(mel + 1e-9)
    if normalize:
        mel_db = (mel_db - mel_db.mean()) / (mel_db.std() + 1e-8)
    return mel_db.astype(np.float32)


def pad_or_crop(mel, target=TARGET_FRAMES):
    _, t = mel.shape
    if t >= target:
        s = (t - target) // 2
        return mel[:, s:s + target]
    pad = target - t
    return np.pad(mel, ((0, 0), (pad // 2, pad - pad // 2)))


def apply_spec_augment(mel):
    mel   = mel.copy()
    nm, nf = mel.shape
    fm    = int(nm * FREQ_MASK_RATIO)
    tm    = int(nf * TIME_MASK_RATIO)
    if fm > 0:
        f0 = np.random.randint(0, nm - fm)
        mel[f0:f0 + fm, :] = 0.0
    if tm > 0:
        t0 = np.random.randint(0, nf - tm)
        mel[:, t0:t0 + tm] = 0.0
    return mel


def extract_features(windows, augment=False, aug_multiplier=1):
    features = []
    for win in windows:
        mel = pad_or_crop(audio_to_melspec(win))
        features.append(mel)
        if augment:
            for _ in range(aug_multiplier - 1):
                aug = apply_spec_augment(mel) * np.random.uniform(0.8, 1.2)
                features.append(aug)
    return features
