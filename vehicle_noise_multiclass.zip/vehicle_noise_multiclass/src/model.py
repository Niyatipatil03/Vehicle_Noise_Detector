# src/model.py — Multi-class VehicleNoiseNet

import torch
import torch.nn as nn
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import DROPOUT_CONV, DROPOUT_FC, HIDDEN_DIM, N_MELS, TARGET_FRAMES, NUM_CLASSES


class ConvBlock(nn.Module):
    def __init__(self, in_ch, out_ch, kernel, padding, pool=True, dropout=DROPOUT_CONV):
        super().__init__()
        layers = [
            nn.Conv2d(in_ch, out_ch, kernel_size=kernel, padding=padding, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        ]
        if pool:    layers.append(nn.MaxPool2d(2, 2))
        if dropout: layers.append(nn.Dropout2d(dropout))
        self.block = nn.Sequential(*layers)

    def forward(self, x): return self.block(x)


class VehicleNoiseNet(nn.Module):
    """
    Multi-class CNN for vehicle noise classification.
    Input : (batch, 1, N_MELS, TARGET_FRAMES)
    Output: (batch, NUM_CLASSES) — raw logits, apply softmax for probabilities
    """
    def __init__(self, num_classes=NUM_CLASSES):
        super().__init__()
        self.num_classes = num_classes

        self.features = nn.Sequential(
            ConvBlock(1,   32, kernel=(7, 3), padding=(3, 1), pool=True,  dropout=0.20),
            ConvBlock(32,  64, kernel=(5, 3), padding=(2, 1), pool=True,  dropout=0.25),
            ConvBlock(64, 128, kernel=(3, 3), padding=(1, 1), pool=True,  dropout=0.25),
            ConvBlock(128,128, kernel=(3, 3), padding=(1, 1), pool=False, dropout=0.00),
            nn.AdaptiveAvgPool2d((4, 4)),
        )

        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(128 * 4 * 4, HIDDEN_DIM),
            nn.ReLU(inplace=True),
            nn.Dropout(DROPOUT_FC),
            nn.Linear(HIDDEN_DIM, HIDDEN_DIM // 2),
            nn.ReLU(inplace=True),
            nn.Dropout(DROPOUT_FC * 0.5),
            nn.Linear(HIDDEN_DIM // 2, num_classes),  # multi-class output
        )
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                nn.init.constant_(m.bias, 0)

    def forward(self, x):
        return self.classifier(self.features(x))

    def predict_proba(self, x):
        with torch.no_grad():
            return torch.softmax(self.forward(x), dim=1)

    def count_parameters(self):
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


if __name__ == "__main__":
    model = VehicleNoiseNet()
    dummy = torch.randn(4, 1, N_MELS, TARGET_FRAMES)
    out   = model(dummy)
    probs = torch.softmax(out, dim=1)
    print(f"Output shape : {out.shape}")
    print(f"Parameters   : {model.count_parameters():,}")
    print(f"Classes      : {NUM_CLASSES}")
    print("Model OK.")
