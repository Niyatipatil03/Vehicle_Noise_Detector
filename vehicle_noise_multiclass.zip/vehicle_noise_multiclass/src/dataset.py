# src/dataset.py — Multi-class dataset builder
# Handles two types of files:
#   1. Single-class files in data/ClassName/ folders
#   2. Mixed files in data/mixed/ with Audacity .txt label files

import os, sys, pickle
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import (
    CLASSES, CLASS_TO_IDX, SINGLE_CLASS_DIRS, MIXED_DIR,
    SAMPLE_RATE, WINDOW_SEC, HOP_SEC,
    WINDOW_SKIP_THRESHOLD, SILENCE_THRESHOLD,
    AUGMENT, AUG_MULTIPLIER, OUTPUTS_DIR, RANDOM_SEED
)
from src.audio_utils import (
    load_wav, remove_speech_energy_vad,
    slice_audio, slice_audio_segment, is_valid_window
)
from src.audacity_labels import parse_audacity_labels, get_label_file
from src.features import extract_features

import torch
from torch.utils.data import Dataset


class VehicleNoiseDataset(Dataset):
    def __init__(self, features, labels):
        self.X = [torch.FloatTensor(f).unsqueeze(0) for f in features]
        self.y = torch.LongTensor(labels)   # LongTensor for CrossEntropyLoss

    def __len__(self):  return len(self.X)
    def __getitem__(self, i): return self.X[i], self.y[i]


def collect_audio_files(directory):
    if not os.path.exists(directory):
        return []
    return [
        os.path.join(directory, f)
        for f in sorted(os.listdir(directory))
        if f.lower().endswith(('.wav', '.mp3', '.m4a'))
    ]


def process_single_class_file(path, class_idx, augment=False, aug_multiplier=1):
    """Process a file from a single-class folder — every window gets same label."""
    try:
        audio, sr = load_wav(path, SAMPLE_RATE)
    except Exception as e:
        print(f"  [ERROR] {os.path.basename(path)}: {e}")
        return [], []

    clean, speech_pct = remove_speech_energy_vad(audio, sr)
    all_windows = slice_audio(clean, sr, WINDOW_SEC, HOP_SEC)
    valid = [w for w in all_windows if is_valid_window(w, WINDOW_SKIP_THRESHOLD, SILENCE_THRESHOLD)]

    if not valid:
        print(f"  [WARN] No valid windows: {os.path.basename(path)}")
        return [], []

    features = extract_features(valid, augment=augment, aug_multiplier=aug_multiplier)
    labels   = [class_idx] * len(features)

    cls_name = CLASSES[class_idx]
    aug_str  = f" → {len(features)} augmented" if augment else ""
    print(f"  [{cls_name:<16}] {os.path.basename(path):<45} "
          f"| {len(valid)} windows{aug_str} | speech: {speech_pct:.1f}%")

    return features, labels


def process_mixed_file(audio_path, txt_path, augment=False, aug_multiplier=1):
    """
    Process a file with Audacity label annotations.
    Different time segments get different class labels.
    """
    try:
        audio, sr = load_wav(audio_path, SAMPLE_RATE)
    except Exception as e:
        print(f"  [ERROR] {os.path.basename(audio_path)}: {e}")
        return [], []

    clean, speech_pct = remove_speech_energy_vad(audio, sr)
    segments = parse_audacity_labels(txt_path)

    if not segments:
        print(f"  [WARN] No valid segments in {os.path.basename(txt_path)}")
        return [], []

    all_features, all_labels = [], []
    for seg in segments:
        windows = slice_audio_segment(
            clean, sr, seg['start'], seg['end'], WINDOW_SEC, HOP_SEC
        )
        valid = [w for w in windows if is_valid_window(w, WINDOW_SKIP_THRESHOLD, SILENCE_THRESHOLD)]
        if not valid:
            continue
        feats  = extract_features(valid, augment=augment, aug_multiplier=aug_multiplier)
        labels = [seg['class_idx']] * len(feats)
        all_features.extend(feats)
        all_labels.extend(labels)

    print(f"  [MIXED           ] {os.path.basename(audio_path):<45} "
          f"| {len(all_labels)} windows | "
          f"classes: {list(set(CLASSES[l] for l in all_labels))} "
          f"| speech: {speech_pct:.1f}%")

    return all_features, all_labels


def build_full_dataset(augment=AUGMENT, aug_multiplier=AUG_MULTIPLIER, cache_path=None):
    if cache_path and os.path.exists(cache_path):
        print(f"Loading cached dataset from {cache_path}")
        with open(cache_path, 'rb') as f:
            return pickle.load(f)

    np.random.seed(RANDOM_SEED)
    all_features, all_labels = [], []

    # ── Single-class folders ─────────────────────────────────────────────────
    print(f"\n{'='*70}")
    print(" PROCESSING SINGLE-CLASS FOLDERS")
    print(f"{'='*70}")
    for cls_name, folder in SINGLE_CLASS_DIRS.items():
        files = collect_audio_files(folder)
        if not files:
            print(f"  [{cls_name}] No files found — skipping")
            continue
        print(f"\n  --- {cls_name} ({len(files)} files) ---")
        for path in files:
            feats, labs = process_single_class_file(
                path, CLASS_TO_IDX[cls_name], augment, aug_multiplier
            )
            all_features.extend(feats)
            all_labels.extend(labs)

    # ── Mixed / Audacity annotated files ─────────────────────────────────────
    mixed_files = collect_audio_files(MIXED_DIR)
    if mixed_files:
        print(f"\n{'='*70}")
        print(" PROCESSING MIXED FILES (Audacity annotations)")
        print(f"{'='*70}")
        for audio_path in mixed_files:
            txt_path = get_label_file(audio_path)
            if txt_path is None:
                print(f"  [WARN] No label file for {os.path.basename(audio_path)} — skipping")
                print(f"         Expected: {os.path.splitext(audio_path)[0]}.txt")
                continue
            feats, labs = process_mixed_file(
                audio_path, txt_path, augment, aug_multiplier
            )
            all_features.extend(feats)
            all_labels.extend(labs)

    # ── Summary ───────────────────────────────────────────────────────────────
    print(f"\n{'='*70}")
    print(" DATASET SUMMARY")
    print(f"{'='*70}")
    if not all_labels:
        print("  [ERROR] No data found!")
        print("  Add .wav files to:")
        for cls, folder in SINGLE_CLASS_DIRS.items():
            print(f"    {folder}")
        print(f"  Or add annotated files to: {MIXED_DIR}")
        return [], []

    from collections import Counter
    counts = Counter(all_labels)
    total  = len(all_labels)
    for idx, cls in enumerate(CLASSES):
        n = counts.get(idx, 0)
        bar = '█' * int(20 * n / max(counts.values(), 1))
        print(f"  {cls:<20} {n:>5} windows  {bar}")
    print(f"\n  Total: {total} windows across {len(counts)} classes")

    if cache_path:
        os.makedirs(os.path.dirname(cache_path), exist_ok=True)
        with open(cache_path, 'wb') as f:
            pickle.dump((all_features, all_labels), f)
        print(f"  Dataset cached → {cache_path}")

    return all_features, all_labels
