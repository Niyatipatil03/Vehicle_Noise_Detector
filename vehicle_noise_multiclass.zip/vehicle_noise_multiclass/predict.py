# predict.py — Multi-class inference

import os, sys, argparse
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import (
    CLASSES, IDX_TO_CLASS, CLASS_DISPLAY, CLASS_COLORS,
    MODELS_DIR, OUTPUTS_DIR, SAMPLE_RATE,
    WINDOW_SEC, HOP_SEC, WINDOW_SKIP_THRESHOLD,
    SILENCE_THRESHOLD, CONFIDENCE_THRESHOLD, VOTE_THRESHOLD
)
from src.audio_utils import load_wav, remove_speech_energy_vad, slice_audio, is_valid_window
from src.features import extract_features
from src.model import VehicleNoiseNet

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
os.makedirs(OUTPUTS_DIR, exist_ok=True)


def load_model(path=None):
    path = path or os.path.join(MODELS_DIR, 'best_model.pt')
    if not os.path.exists(path):
        raise FileNotFoundError(f"No model at {path}. Run train.py first.")
    model = VehicleNoiseNet().to(DEVICE)
    ckpt  = torch.load(path, map_location=DEVICE)
    model.load_state_dict(ckpt['model_state'])
    model.eval()
    print(f"  Model loaded — val_f1: {ckpt.get('val_f1', 0):.4f}  "
          f"(fold {ckpt.get('fold', '?')})")
    return model


def predict_file(path, model, save_plot=True):
    audio, sr = load_wav(path, SAMPLE_RATE)
    clean, speech_pct = remove_speech_energy_vad(audio, sr)

    windows = slice_audio(clean, sr, WINDOW_SEC, HOP_SEC)
    valid   = [w for w in windows if is_valid_window(w, WINDOW_SKIP_THRESHOLD, SILENCE_THRESHOLD)]

    if not valid:
        print(f"  No valid windows in {os.path.basename(path)}")
        return None

    features = extract_features(valid, augment=False)
    all_probs = []

    with torch.no_grad():
        for feat in features:
            tensor = torch.FloatTensor(feat).unsqueeze(0).unsqueeze(0).to(DEVICE)
            probs  = torch.softmax(model(tensor), dim=1).cpu().numpy()[0]
            all_probs.append(probs)

    all_probs = np.array(all_probs)   # (n_windows, num_classes)
    mean_probs = all_probs.mean(axis=0)

    # Voting: count which class each window votes for
    window_votes = np.argmax(all_probs, axis=1)
    vote_counts  = np.bincount(window_votes, minlength=len(CLASSES))
    vote_fractions = vote_counts / len(window_votes)

    # Final prediction — highest mean probability class
    predicted_idx   = int(np.argmax(mean_probs))
    predicted_class = IDX_TO_CLASS[predicted_idx]
    confidence      = float(mean_probs[predicted_idx])

    # If confidence is below threshold → uncertain
    if confidence < CONFIDENCE_THRESHOLD:
        predicted_class = "UNCERTAIN"

    print(f"\n  File    : {os.path.basename(path)}")
    print(f"  Speech  : {speech_pct:.1f}% removed")
    print(f"  Windows : {len(valid)}")
    print(f"\n  ┌─────────────────────────────────────┐")
    print(f"  │  RESULT  : {CLASS_DISPLAY.get(predicted_class, predicted_class):<25}│")
    print(f"  │  Confidence : {confidence:.1%:<24}│")
    print(f"  └─────────────────────────────────────┘")
    print(f"\n  Per-class probabilities:")
    for i, cls in enumerate(CLASSES):
        bar  = '█' * int(20 * mean_probs[i])
        flag = ' ◄' if i == predicted_idx else ''
        print(f"    {cls:<20} {mean_probs[i]:.3f}  {bar}{flag}")

    if save_plot:
        _save_plot(path, audio, sr, all_probs, mean_probs,
                   predicted_class, confidence, speech_pct)

    return {
        'file':            os.path.basename(path),
        'predicted_class': predicted_class,
        'confidence':      confidence,
        'mean_probs':      mean_probs.tolist(),
        'window_votes':    vote_fractions.tolist(),
        'speech_pct':      speech_pct,
        'n_windows':       len(valid),
    }


def _save_plot(path, audio, sr, all_probs, mean_probs,
               predicted_class, confidence, speech_pct):
    fname = os.path.splitext(os.path.basename(path))[0]
    out   = os.path.join(OUTPUTS_DIR, f"prediction_{fname}.png")
    color = CLASS_COLORS.get(predicted_class, '#888888')

    fig, axes = plt.subplots(1, 3, figsize=(18, 5), facecolor='#0f0f1a')
    BG = '#0d0d1a'

    # Waveform
    ax = axes[0]
    t  = np.linspace(0, len(audio) / sr, len(audio))
    ax.plot(t[::200], audio[::200], color='#00a8ff', linewidth=0.4, alpha=0.7)
    ax.set_facecolor(BG)
    ax.set_title('Waveform', color='white', fontsize=10)
    ax.set_xlabel('Time (s)', color='#aaa', fontsize=9)
    ax.tick_params(colors='#666')
    for sp in ax.spines.values(): sp.set_color('#333')

    # Per-class probability bar chart
    ax = axes[1]
    colors_list = [CLASS_COLORS[c] for c in CLASSES]
    bars = ax.barh(CLASSES, mean_probs, color=colors_list, alpha=0.85)
    ax.set_facecolor(BG)
    ax.set_title('Class Probabilities', color='white', fontsize=10)
    ax.set_xlim(0, 1)
    ax.axvline(CONFIDENCE_THRESHOLD, color='white', linewidth=1,
               linestyle='--', alpha=0.4)
    ax.tick_params(colors='#888')
    for sp in ax.spines.values(): sp.set_color('#333')
    for bar, prob in zip(bars, mean_probs):
        ax.text(min(prob + 0.02, 0.95), bar.get_y() + bar.get_height() / 2,
                f'{prob:.2f}', va='center', color='white', fontsize=9)

    # Window-by-window heatmap
    ax = axes[2]
    im = ax.imshow(
        all_probs.T, aspect='auto', origin='lower',
        extent=[0, len(all_probs), -0.5, len(CLASSES) - 0.5],
        cmap='hot', vmin=0, vmax=1
    )
    ax.set_yticks(range(len(CLASSES)))
    ax.set_yticklabels(CLASSES, fontsize=8)
    ax.set_facecolor(BG)
    ax.set_title('Per-Window Probabilities', color='white', fontsize=10)
    ax.set_xlabel('Window index', color='#aaa', fontsize=9)
    ax.tick_params(colors='#888')
    for sp in ax.spines.values(): sp.set_color('#333')
    plt.colorbar(im, ax=ax)

    fig.suptitle(
        f"{os.path.basename(path)}  →  "
        f"{CLASS_DISPLAY.get(predicted_class, predicted_class)}  "
        f"({confidence:.1%} confidence)",
        color=color, fontsize=13, fontweight='bold'
    )
    plt.tight_layout()
    plt.savefig(out, dpi=130, bbox_inches='tight', facecolor='#0f0f1a')
    plt.close()
    print(f"  Plot saved → {out}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("files", nargs="+", help=".wav files to analyze")
    parser.add_argument("--model", default=None)
    args = parser.parse_args()

    model = load_model(args.model)
    for f in args.files:
        if os.path.exists(f):
            predict_file(f, model)
        else:
            print(f"  Not found: {f}")
