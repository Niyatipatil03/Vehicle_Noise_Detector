# Vehicle Noise Multi-Class Detector

Classifies vehicle noise into 7 categories: OK, IP Noise, Steering Noise,
Sunroof Noise, Door Noise, Seat Noise, Seat Belt Noise.

---

## Data folder structure

```
data/
├── OK/                  ← Vehicle passes QC — put OK .wav files here
├── IP_Noise/            ← Instrument panel rattle files
├── Steering_Noise/      ← Steering column noise files
├── Sunroof_Noise/       ← Sunroof seal/rattle files
├── Door_Noise/          ← Door trim rattle files
├── Seat_Noise/          ← Seat squeak/rattle files
├── Seat_Belt_Noise/     ← Seat belt noise files
└── mixed/               ← Files with MULTIPLE noise types
    ├── vehicle_001.wav  ← audio file
    └── vehicle_001.txt  ← Audacity label file (same base name)
```

---

## How to annotate mixed files in Audacity

1. Open your .wav file in Audacity
2. **Tracks → Add New → Label Track**
3. Click and drag to select a region → press **Ctrl+B** → type the label name
4. Use EXACTLY these label names (case-sensitive):
   - `OK`
   - `IP_Noise`
   - `Steering_Noise`
   - `Sunroof_Noise`
   - `Door_Noise`
   - `Seat_Noise`
   - `Seat_Belt_Noise`
5. **File → Export → Export Labels**
6. Save as `<same_name_as_audio>.txt` in the same `mixed/` folder

---

## How to run

```bash
# Install packages
pip install numpy scikit-learn matplotlib soundfile seaborn tqdm pandas
pip install torch torchaudio --index-url https://download.pytorch.org/whl/cpu

# Validate your labels first
python validate_labels.py

# Train
python train.py

# Predict on a new file
python predict.py path/to/vehicle.wav
```

---

## Adding a new noise class later

1. Add the class name to `CLASSES` list in `config.py`
2. Add its color to `CLASS_COLORS` in `config.py`
3. Create a new folder `data/NewClass/` and add .wav files
4. Delete `outputs/dataset_cache.pkl`
5. Run `python train.py`
