# config.py — Central configuration for Vehicle Noise Multi-Class Detector

import os

# ── Paths ─────────────────────────────────────────────────────────────────────
BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
DATA_DIR    = os.path.join(BASE_DIR, "data")
MODELS_DIR  = os.path.join(BASE_DIR, "models")
OUTPUTS_DIR = os.path.join(BASE_DIR, "outputs")

# ── Noise Classes ─────────────────────────────────────────────────────────────
# ORDER MATTERS — index = class label used by model
# To add a new class: append to this list and create matching data/ folder
CLASSES = [
    "OK",
    "IP_Noise",
    "Steering_Noise",
    "Sunroof_Noise",
    "Door_Noise",
    "Seat_Noise",
    "Seat_Belt_Noise",
]

NUM_CLASSES  = len(CLASSES)
CLASS_TO_IDX = {c: i for i, c in enumerate(CLASSES)}
IDX_TO_CLASS = {i: c for i, c in enumerate(CLASSES)}

# Display names for UI (used in Flutter app and reports)
CLASS_DISPLAY = {
    "OK":             "Vehicle OK",
    "IP_Noise":       "IP Panel Noise",
    "Steering_Noise": "Steering Noise",
    "Sunroof_Noise":  "Sunroof Noise",
    "Door_Noise":     "Door Noise",
    "Seat_Noise":     "Seat Noise",
    "Seat_Belt_Noise":"Seat Belt Noise",
}

# Color codes for each class (used in plots and Flutter UI)
CLASS_COLORS = {
    "OK":             "#00C853",
    "IP_Noise":       "#FF6D00",
    "Steering_Noise": "#2979FF",
    "Sunroof_Noise":  "#AA00FF",
    "Door_Noise":     "#FFD600",
    "Seat_Noise":     "#00BCD4",
    "Seat_Belt_Noise":"#F50057",
}

# Data folders — one folder per single-class file, plus "mixed" for annotated files
SINGLE_CLASS_DIRS = {
    cls: os.path.join(DATA_DIR, cls) for cls in CLASSES
}
MIXED_DIR = os.path.join(DATA_DIR, "mixed")   # files with Audacity .txt label files

# ── Audio ─────────────────────────────────────────────────────────────────────
SAMPLE_RATE   = 22050
WINDOW_SEC    = 3.0
HOP_SEC       = 1.0
MIN_AUDIO_SEC = 1.0

# ── Speech Removal ────────────────────────────────────────────────────────────
SPEECH_ENERGY_THRESHOLD = -20.0
SILENCE_THRESHOLD       = -50.0
WINDOW_SKIP_THRESHOLD   = -15.0
SPEECH_REPLACEMENT_AMP  = 0.002

# ── Features ──────────────────────────────────────────────────────────────────
N_FFT         = 2048
HOP_LENGTH    = 512
N_MELS        = 128
F_MIN         = 300
F_MAX         = 10000
TARGET_FRAMES = 128

# ── Augmentation ──────────────────────────────────────────────────────────────
AUGMENT        = True
AUG_MULTIPLIER = 20
TIME_MASK_RATIO = 0.10
FREQ_MASK_RATIO = 0.10

# ── Model ─────────────────────────────────────────────────────────────────────
DROPOUT_CONV = 0.25
DROPOUT_FC   = 0.40
HIDDEN_DIM   = 256   # larger than binary model to handle 7 classes

# ── Training ──────────────────────────────────────────────────────────────────
K_FOLDS       = 5
EPOCHS        = 60
BATCH_SIZE    = 32
LEARNING_RATE = 3e-4
WEIGHT_DECAY  = 1e-3
PATIENCE      = 12
RANDOM_SEED   = 42

# ── Inference ─────────────────────────────────────────────────────────────────
# Minimum probability for a class to be reported (below = uncertain)
CONFIDENCE_THRESHOLD = 0.40
# Fraction of windows that must agree on a class for final verdict
VOTE_THRESHOLD       = 0.30
