# train.py — Multi-class K-Fold training

import os, sys, json, shutil
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import classification_report, confusion_matrix, f1_score
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import (
    CLASSES, NUM_CLASSES, CLASS_COLORS, MODELS_DIR, OUTPUTS_DIR,
    K_FOLDS, EPOCHS, BATCH_SIZE, LEARNING_RATE, WEIGHT_DECAY,
    PATIENCE, RANDOM_SEED, AUGMENT, AUG_MULTIPLIER
)
from src.dataset import build_full_dataset, VehicleNoiseDataset
from src.model import VehicleNoiseNet

os.makedirs(MODELS_DIR,  exist_ok=True)
os.makedirs(OUTPUTS_DIR, exist_ok=True)
torch.manual_seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def compute_class_weights(labels):
    """Inverse-frequency weights to handle class imbalance."""
    counts = np.bincount(labels, minlength=NUM_CLASSES).astype(float)
    counts = np.where(counts == 0, 1, counts)
    weights = 1.0 / counts
    weights = weights / weights.sum() * NUM_CLASSES
    return torch.FloatTensor(weights).to(DEVICE)


def get_metrics(model, loader):
    model.eval()
    all_preds, all_labels, all_probs = [], [], []
    total_loss = 0.0
    criterion  = nn.CrossEntropyLoss()

    with torch.no_grad():
        for xb, yb in loader:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            logits = model(xb)
            loss   = criterion(logits, yb)
            total_loss += loss.item() * len(yb)
            probs  = torch.softmax(logits, dim=1).cpu().numpy()
            preds  = np.argmax(probs, axis=1)
            all_probs.extend(probs.tolist())
            all_preds.extend(preds.tolist())
            all_labels.extend(yb.cpu().numpy().tolist())

    avg_loss = total_loss / len(loader.dataset)
    acc      = sum(p == l for p, l in zip(all_preds, all_labels)) / len(all_labels)
    f1_macro = f1_score(all_labels, all_preds, average='macro', zero_division=0)
    f1_per   = f1_score(all_labels, all_preds, average=None,
                        labels=list(range(NUM_CLASSES)), zero_division=0)
    return avg_loss, acc, f1_macro, f1_per, all_preds, all_labels


def plot_confusion_matrix(cm, fold, save_path):
    fig, ax = plt.subplots(figsize=(10, 8), facecolor='#0f0f1a')
    short_labels = [c.replace('_Noise', '').replace('_', '\n') for c in CLASSES]
    colors = [CLASS_COLORS[c] for c in CLASSES]

    sns.heatmap(
        cm, annot=True, fmt='d', ax=ax,
        xticklabels=short_labels, yticklabels=short_labels,
        cmap='Reds', linewidths=0.5,
        annot_kws={'size': 11, 'weight': 'bold'},
    )
    ax.set_title(f'Confusion Matrix — Fold {fold}',
                 color='white', fontsize=13, fontweight='bold', pad=15)
    ax.set_xlabel('Predicted', color='#aaa', fontsize=11)
    ax.set_ylabel('Actual',    color='#aaa', fontsize=11)
    ax.tick_params(colors='#aaa', labelsize=9)
    fig.patch.set_facecolor('#0f0f1a')
    plt.tight_layout()
    plt.savefig(save_path, dpi=130, bbox_inches='tight', facecolor='#0f0f1a')
    plt.close()


def plot_per_class_f1(f1_scores_per_fold, save_path):
    """Bar chart showing per-class F1 across folds."""
    mean_f1 = np.mean(f1_scores_per_fold, axis=0)
    std_f1  = np.std(f1_scores_per_fold,  axis=0)

    fig, ax = plt.subplots(figsize=(12, 5), facecolor='#0f0f1a')
    x       = np.arange(NUM_CLASSES)
    colors  = [CLASS_COLORS[c] for c in CLASSES]
    bars    = ax.bar(x, mean_f1, yerr=std_f1, color=colors, alpha=0.85,
                     capsize=5, width=0.6, error_kw={'color': 'white', 'linewidth': 1.5})

    ax.set_facecolor('#0d0d1a')
    ax.set_xticks(x)
    ax.set_xticklabels(
        [c.replace('_Noise', '\nNoise').replace('_', '\n') for c in CLASSES],
        color='#aaa', fontsize=9
    )
    ax.set_ylabel('F1 Score', color='#aaa')
    ax.set_ylim(0, 1.05)
    ax.set_title('Per-Class F1 Score (mean ± std across folds)',
                 color='white', fontsize=12, fontweight='bold')
    ax.tick_params(colors='#666')
    for sp in ax.spines.values(): sp.set_color('#333')
    fig.patch.set_facecolor('#0f0f1a')

    for bar, v in zip(bars, mean_f1):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.02,
                f'{v:.2f}', ha='center', va='bottom', color='white', fontsize=9)

    plt.tight_layout()
    plt.savefig(save_path, dpi=130, bbox_inches='tight', facecolor='#0f0f1a')
    plt.close()


def train():
    print(f"\n{'='*70}")
    print(" VEHICLE NOISE DETECTOR — MULTI-CLASS TRAINING")
    print(f"{'='*70}")
    print(f" Classes : {CLASSES}")
    print(f" Device  : {DEVICE}")
    print(f" Folds   : {K_FOLDS}  Epochs: {EPOCHS}  Batch: {BATCH_SIZE}")

    cache = os.path.join(OUTPUTS_DIR, "dataset_cache.pkl")
    features, labels = build_full_dataset(cache_path=cache)

    if not features:
        return

    X = np.array(labels)
    skf = StratifiedKFold(n_splits=K_FOLDS, shuffle=True, random_state=RANDOM_SEED)

    fold_results       = []
    all_f1_per_class   = []

    for fold, (tr_idx, vl_idx) in enumerate(skf.split(X, X)):
        fold_num = fold + 1
        print(f"\n{'─'*70}")
        print(f" FOLD {fold_num}/{K_FOLDS} — train: {len(tr_idx)}  val: {len(vl_idx)}")
        print(f"{'─'*70}")

        tr_feats = [features[i] for i in tr_idx]
        tr_labs  = [labels[i]   for i in tr_idx]
        vl_feats = [features[i] for i in vl_idx]
        vl_labs  = [labels[i]   for i in vl_idx]

        tr_ds = VehicleNoiseDataset(tr_feats, tr_labs)
        vl_ds = VehicleNoiseDataset(vl_feats, vl_labs)
        tr_dl = DataLoader(tr_ds, batch_size=BATCH_SIZE, shuffle=True,  num_workers=0)
        vl_dl = DataLoader(vl_ds, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)

        model     = VehicleNoiseNet().to(DEVICE)
        weights   = compute_class_weights(np.array(tr_labs))
        criterion = nn.CrossEntropyLoss(weight=weights)
        optimizer = optim.AdamW(model.parameters(),
                                lr=LEARNING_RATE, weight_decay=WEIGHT_DECAY)
        scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS)

        best_val_f1   = 0.0
        patience_wait = 0
        best_path     = os.path.join(MODELS_DIR, f"best_fold{fold_num}.pt")

        for epoch in range(1, EPOCHS + 1):
            model.train()
            tr_loss = 0.0
            for xb, yb in tr_dl:
                xb, yb = xb.to(DEVICE), yb.to(DEVICE)
                optimizer.zero_grad()
                loss = criterion(model(xb), yb)
                loss.backward()
                nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimizer.step()
                tr_loss += loss.item() * len(yb)
            scheduler.step()

            vl_loss, vl_acc, vl_f1, vl_f1_per, vl_preds, vl_true = \
                get_metrics(model, vl_dl)

            if epoch % 5 == 0 or epoch == 1:
                print(f"  Epoch {epoch:3d} | tr_loss: {tr_loss/len(tr_ds):.4f} | "
                      f"val_acc: {vl_acc:.3f} | val_f1: {vl_f1:.3f}")

            if vl_f1 > best_val_f1:
                best_val_f1   = vl_f1
                patience_wait = 0
                torch.save({
                    'fold': fold_num, 'epoch': epoch,
                    'model_state': model.state_dict(),
                    'val_f1': vl_f1, 'val_acc': vl_acc,
                    'classes': CLASSES,
                }, best_path)
            else:
                patience_wait += 1
                if patience_wait >= PATIENCE:
                    print(f"  Early stop at epoch {epoch}")
                    break

        # Evaluate best model
        ckpt = torch.load(best_path, map_location=DEVICE)
        model.load_state_dict(ckpt['model_state'])
        _, _, _, final_f1_per, final_preds, final_true = get_metrics(model, vl_dl)

        cm     = confusion_matrix(final_true, final_preds, labels=list(range(NUM_CLASSES)))
        report = classification_report(
            final_true, final_preds,
            target_names=CLASSES, zero_division=0
        )
        print(f"\n{report}")

        plot_confusion_matrix(
            cm, fold_num,
            os.path.join(OUTPUTS_DIR, f"confusion_fold{fold_num}.png")
        )
        all_f1_per_class.append(final_f1_per)
        fold_results.append({'fold': fold_num, 'val_f1': best_val_f1})

    # ── Final summary ─────────────────────────────────────────────────────────
    f1s = [r['val_f1'] for r in fold_results]
    print(f"\n{'='*70}")
    print(" FINAL RESULTS")
    print(f"{'='*70}")
    for r in fold_results:
        print(f"  Fold {r['fold']} — macro F1: {r['val_f1']:.4f}")
    print(f"\n  Mean macro F1 : {np.mean(f1s):.4f} ± {np.std(f1s):.4f}")

    # Per-class F1 chart
    plot_per_class_f1(
        all_f1_per_class,
        os.path.join(OUTPUTS_DIR, 'per_class_f1.png')
    )

    # Save best overall model
    best_fold = fold_results[np.argmax(f1s)]['fold']
    shutil.copy(
        os.path.join(MODELS_DIR, f"best_fold{best_fold}.pt"),
        os.path.join(MODELS_DIR, "best_model.pt")
    )
    print(f"\n  Best model (Fold {best_fold}) → models/best_model.pt")

    summary = {
        'classes': CLASSES,
        'num_classes': NUM_CLASSES,
        'mean_f1': float(np.mean(f1s)),
        'std_f1':  float(np.std(f1s)),
        'per_class_f1': {
            CLASSES[i]: float(np.mean([f[i] for f in all_f1_per_class]))
            for i in range(NUM_CLASSES)
        },
        'best_fold': best_fold,
    }
    with open(os.path.join(OUTPUTS_DIR, 'training_summary.json'), 'w') as f:
        json.dump(summary, f, indent=2)

    print("\n  Outputs saved to outputs/")
    print("  Training complete!\n")


if __name__ == "__main__":
    train()
