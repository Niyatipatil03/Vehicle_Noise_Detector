# validate_labels.py
# Run this BEFORE training to check all your Audacity label files are correct.
# Catches typos, missing files, wrong timestamps.
#
# Usage:
#   python validate_labels.py

import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import CLASSES, MIXED_DIR, SINGLE_CLASS_DIRS
from src.audio_utils import load_wav
from src.audacity_labels import parse_audacity_labels, get_label_file, validate_label_file
from src.dataset import collect_audio_files


def main():
    print("=" * 60)
    print(" LABEL VALIDATION TOOL")
    print("=" * 60)

    issues = 0

    # ── Check single-class folders ────────────────────────────────────────────
    print("\n--- Single-class folders ---")
    for cls, folder in SINGLE_CLASS_DIRS.items():
        files = collect_audio_files(folder)
        if files:
            print(f"  [{cls}] {len(files)} files — OK")
        else:
            print(f"  [{cls}] No files — folder empty or missing")

    # ── Check mixed / annotated files ─────────────────────────────────────────
    mixed_files = collect_audio_files(MIXED_DIR)
    if not mixed_files:
        print(f"\n  No mixed files found in {MIXED_DIR}")
        print("  (This is fine if all your files are in single-class folders)")
    else:
        print(f"\n--- Mixed files ({len(mixed_files)} audio files) ---")
        for audio_path in mixed_files:
            txt_path = get_label_file(audio_path)
            fname    = os.path.basename(audio_path)

            if txt_path is None:
                print(f"\n  [MISSING LABEL] {fname}")
                print(f"    Expected label file: "
                      f"{os.path.splitext(audio_path)[0]}.txt")
                issues += 1
                continue

            print(f"\n  {fname}")
            try:
                audio, sr = load_wav(audio_path)
                duration  = len(audio) / sr
                print(f"    Duration: {duration:.1f}s")
                validate_label_file(txt_path, duration)

                # Show all segments
                segments = parse_audacity_labels(txt_path)
                for seg in segments:
                    print(f"    [{seg['start']:6.1f}s → {seg['end']:6.1f}s]  "
                          f"{seg['label']}")
            except Exception as e:
                print(f"    [ERROR] {e}")
                issues += 1

    # ── Summary ───────────────────────────────────────────────────────────────
    print(f"\n{'='*60}")
    if issues == 0:
        print("  All checks passed — ready to train!")
        print("  Run: python train.py")
    else:
        print(f"  {issues} issue(s) found — fix them before training")
    print("=" * 60)


if __name__ == "__main__":
    main()
